<?php
?>
<div id="mobileView">
    <p> This website is not available for  mobile. Please use desktop or laptop to access.</p>
</div>